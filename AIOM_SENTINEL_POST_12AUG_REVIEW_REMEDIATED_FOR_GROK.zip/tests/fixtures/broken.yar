rule BrokenFixture {
    condition:
